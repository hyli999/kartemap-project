dbc.Row(
    dbc.Col(
        dbc.Card(
            dbc.CardBody(html.Div(id='destination-city-info'),
                         style={
                             'textAlign': 'left',
                             'color': '#173F5F',
                             'fontSize': 18
                         },
                         ),
            color="secondary", inverse=True, className="bg-info",

        )
    )
),


@app.callback(Output('destination-city-info', 'children'),
               Input('destination-city', 'value'))

#search for descriptions of corresponding destination cities
def destination_city_description(destination_city):
    if destination_city == 'New York City':
        return f'Welcome to {destination_city}. New York City (NYC), often simply called New York, is the most populous city in the United States. Located at the southern tip of the State of New York, the city is the center of the New York metropolitan area, the largest metropolitan area in the world by urban landmass.'
    elif destination_city == "Los Angeles":
        return f'Welcome to {destination_city}. Los Angeles is the largest city in California. With an estimated population of nearly four million people, it is the second most populous city in the United States (after New York City) and the third most populous city in North America (after Mexico City and New York City). Los Angeles is known for its Mediterranean climate, ethnic diversity, Hollywood entertainment industry, and its sprawling metropolis.'
    elif destination_city == "Chicago":
        return f"Welcome to {destination_city}. Chicago is the most populous city in the U.S. state of Illinois, and the third most populous city in the United States. Chicago is an international hub for finance, culture, commerce, industry, education, technology, telecommunications, and transportation. It is the site of the creation of the first standardized futures contracts, issued by the Chicago Board of Trade, which today is part of the largest and most diverse derivatives market in the world, generating 20% of all volume in commodities and financial futures alone."
    elif destination_city == "Dallas":
        return f"Welcome to {destination_city}. Dallas is a city in the U.S. state of Texas and the largest city in and seat of Dallas County. Located in North Texas, the city of Dallas is the main core of the largest metropolitan area in the Southern United States and the largest inland metropolitan area in the U.S. that lacks any navigable link to the sea."
    elif destination_city == "Houston":
        return f"Welcome to {destination_city}. Houston is the most populous city in the U.S. state of Texas, fourth-most populous city in the United States, most populous city in the Southern United States, as well as the sixth-most populous in North America, with an estimated 2019 population of 2,320,268."
    elif destination_city == "Washington":
        return f"Welcome to {destination_city}. Washington, D.C. is the capital city of the United States.It is located on the Potomac River bordering Maryland and Virginia, with Congress holding its first session there in 1800. The city was named for George Washington, the first president of the United States and a Founding Father, and the federal district is named after Columbia, a female personification of the nation. As the seat of the U.S. federal government and several international organizations, the city is an important world political capital."
    elif destination_city == "Miami":
        return f"Welcome to {destination_city}. Miami is a coastal metropolis located in southeastern Florida in the United States. Miami is a major center and leader in finance, commerce, culture, arts, and international trade."
    elif destination_city == "Philadelphia":
        return f"Welcome to {destination_city}. Philadelphia, colloquially Philly, is a city in the state of Pennsylvania in the United States. It is the sixth-most populous city in the United States and the most populous city in the state of Pennsylvania. It is also the second-most populous city in the Northeastern United States, behind New York City."
    elif destination_city == "Atlanta":
        return f"Welcome to {destination_city}. Atlanta is the capital and most populous city of the U.S. state of Georgia. The city serves as the cultural and economic center of the Atlanta metropolitan area, home to more than 6 million people and the ninth-largest metropolitan area in the nation."
    elif destination_city == "Phoenix":
        return f"Welcome to {destination_city}. Phoenix is the capital and most populous city in Arizona, with 1,680,992 people (as of 2019). It is also the fifth-most populous city in the United States, the largest state capital by population,and the only state capital with a population of more than one million residents."
    elif destination_city == "Boston":
        return f"Welcome to {destination_city}. Boston is one of the oldest municipalities in the United States, founded on the Shawmut Peninsula in 1630 by Puritan settlers from the English town of the same name. Upon American independence from Great Britain, the city continued to be an important port and manufacturing hub as well as a center for education and culture. Today, Boston is a thriving center of scientific research. The Boston area's many colleges and universities make it a world leader in higher education."
    elif destination_city == "San Francisco":
        return f"Welcome to {destination_city}. San Francisco is a cultural, commercial, and financial center in Northern California. A popular tourist destination, San Francisco is known for its cool summers, fog, steep rolling hills, eclectic mix of architecture, and landmarks, including the Golden Gate Bridge, cable cars, the former Alcatraz Federal Penitentiary, Fisherman's Wharf, and its Chinatown district."
    elif destination_city == "Detroit":
        return f"Welcome to {destination_city}. Detroit's diverse culture has had both local and international influence, particularly in music, with the city giving rise to the genres of Motown and techno, and playing an important role in the development of jazz, hip-hop, rock, and punk music."
    elif destination_city == "Seattle":
        return f"Welcome to {destination_city}. Seattle is a seaport city on the West Coast of the United States. The Seattle area developed into a technology center from the 1980s onwards with companies like Microsoft becoming established in the region; Microsoft founder Bill Gates is a Seattleite by birth."
    elif destination_city == "Minneapolis":
        return f"Welcome to {destination_city}. Minneapolis is the most populous city in the US state of Minnesota and the seat of Hennepin County. With an estimated population of 429,606 as of 2019, it is the 46th most populous city in the US."
    elif destination_city == "San Diego":
        return f"Welcome to {destination_city}. San Diego is a city in the U.S. state of California on the coast of the Pacific Ocean and immediately adjacent to the United States–Mexico border. The city is known for its mild year-round climate, natural deep-water harbor, extensive beaches and parks, long association with the United States Navy and Marine Corps, and recent emergence as a healthcare and biotechnology development center."
    elif destination_city == "Tampa":
        return f"Welcome to {destination_city}. Tampa is a major city that serves as the county seat of Hillsborough County, Florida, United States. It is on the west coast of Florida on Tampa Bay, near the Gulf of Mexico. Tampa is the largest city in the Tampa Bay area."
    elif destination_city == "Denver":
        return f"Welcome to {destination_city}. Denver is the capital and most populous city of the U.S. State of Colorado. Denver is located in the South Platte River Valley on the western edge of the High Plains just east of the Front Range of the Rocky Mountains."
    elif destination_city == "St. Louis":
        return f"Welcome to {destination_city}. St. Louis is the second-largest city in Missouri, United States. It sits near the confluence of the Mississippi and the Missouri Rivers, on the western bank of the latter."
    elif destination_city == "Baltimore":
        return f"Welcome to {destination_city}. Baltimore is the largest independent city in the country and was designated as such by the Constitution of Maryland in 1851. With hundreds of identified districts, Baltimore has been dubbed a 'city of neighborhoods'. Baltimore has more public statues and monuments per capita than any other city in the country."
    elif destination_city == "Charlotte":
        return f"Welcome to {destination_city}. Charlotte is the most populous city in the U.S. state of North Carolina. The city is the cultural, economic, and transportation center of the Charlotte metropolitan area, whose population ranks 22nd in the U.S., and had a population of 2,569,213, in 2018."
    elif destination_city == "Orlando":
        return f"Welcome to {destination_city}. Orlando is one of the most-visited cities in the world primarily driven by tourism, major events, and convention traffic; in 2018, the city drew more than 75 million visitors."
    elif destination_city == "San Antonio":
        return f"Welcome to {destination_city}. San Antonio is the seventh-most populous city in the United States, and the second-most populous city in both Texas and the Southern United States, with 1,547,253 residents in 2019."
    elif destination_city == "Portland":
        return f"Welcome to {destination_city}. Portland is the largest and most populous city in the U.S. state of Oregon and the seat of Multnomah County. It is a major port in the Willamette Valley region of the Pacific Northwest, at the confluence of the Willamette and Columbia rivers in Northwestern Oregon."

