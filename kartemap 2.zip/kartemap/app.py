from operator import itemgetter

import dash
import dash_bootstrap_components as dbc
import dash_core_components as dcc
import dash_html_components as html
import dash_table
import helper
import plotly.graph_objects as go
# drop down list for use in airport codes
from controls import city_df, airlines_df, routes_df, airport_df
from dash.dependencies import Input, Output, State

# setup app with stylesheets
app = dash.Dash(external_stylesheets=[dbc.themes.MINTY])

# Create map template
mapbox_access_token = \
    'pk.eyJ1IjoiYW5hbWluaSIsImEiOiJja2htbGEwdHcwcWZ3MzVvOTR1amNhajM5In0.tmieTIAQdfvwE4m_WUXuCQ'

layout = dict(
    autosize=True,
    automargin=True,
    margin=dict(l=5, r=5, b=5, t=5),
    hovermode='closest',
    title='Flights, Routes, and Analysis',
    mapbox=dict(
        accesstoken=mapbox_access_token,
        center=dict(lon=-98.5795, lat=39.8283),
        zoom=3,
    ),
)
controls = dbc.Card(
    [
        dbc.FormGroup(
            [
                dbc.Label('Airline', className='text-primary'),
                dcc.Dropdown(
                    options=[{'label': col, 'value': col} for col in airlines_df['Name']],
                    value='',
                    id='airline',
                ),
            ]
        ),
        dbc.FormGroup(
            [
                dbc.Label('Start City', className='text-primary'),
                dcc.Dropdown(
                    options=[{'label': col, 'value': col} for col in city_df['City']],
                    value='',
                    id='start-city',
                    disabled=True
                ),
            ]
        ),
        dbc.FormGroup(
            [
                dbc.Label('Airport of Start City', className='text-primary'),
                dcc.Dropdown(
                    options=[{'label': col, 'value': col} for col in city_df['City']],
                    value='',
                    id='start-city-airport',
                    disabled=True
                ),
            ]
        ),
        dbc.FormGroup(
            [
                dbc.Label('Destination City', className='text-primary'),
                dcc.Dropdown(
                    options=[{'label': col, 'value': col} for col in city_df['City']],
                    value='',
                    id='destination-city',
                    disabled=True
                ),
            ]
        ),
        dbc.FormGroup(
            [
                dbc.Label('Airport of Destination City', className='text-primary'),
                dcc.Dropdown(
                    options=[{'label': col, 'value': col} for col in city_df['City']],
                    value='',
                    id='destination-city-airport',
                    disabled=True
                ),
            ]
        ),
    ],
    body=True,
)

app.layout = dbc.Container(
    [
        dbc.Row(
            [
                dbc.Col(html.H2(), md=3),
                dbc.Col(
                    html.H2('Kartemap - Flight Route Analysis',
                            className='text-white'), md=9
                )
            ], align='center', className='bg-info'),
        dbc.Row(
            [
                dbc.Col(controls, md=4),
                dbc.Col(dcc.Graph(id='map'), md=8),
            ],
            align='center', className='bg-info',
        ),
        dbc.Row(
            [
                dbc.Col(dash_table.DataTable(id='shortest-path-table',), md=12),
            ],
            align='center', className='bg-info',
        ),
        dbc.Row(
            dbc.Col(
                dbc.Card(
                    dbc.CardBody(html.Div(id='display-selected-values'),
                                 style={
                                     'textAlign': 'left',
                                     'color': '#173F5F',
                                     'fontSize': 18
                                 }),
                    color="secondary", inverse=True, className="bg-info",
                )

            )
        ),

        dbc.Row(
            dbc.Col(
                dbc.Card(
                    dbc.CardBody(html.Div(id='destination-city-info'),
                                 style={
                                     'textAlign': 'left',
                                     'color': '#173F5F',
                                     'fontSize': 18
                                 },
                                 ),
                    color="secondary", inverse=True, className="bg-info",

                )
            )
        ),
        dbc.Row(
            [
                dbc.Col(html.H2(), md=3),
                dbc.Col(
                    html.H6('Python and Applications to Business Analytics II: Manqi Wang & Hongyu Li',
                            className='text-white'), md=9
                )
            ], align='center', className='bg-info'),

    ],
    id='main-container',
    #style={'display': 'flex', 'flex-direction': 'column'},
    style={'display': 'flex', 'flexDirection': 'column'},
    fluid=True
)


# airline selected, populate and enable start and destination city controls
#
@app.callback([Output('start-city', 'options'),
               Output('start-city', 'disabled'),
               Output('destination-city', 'options'),
               Output('destination-city', 'disabled')],
              [Input('airline', 'value')])
def populate_city_controls_after_airline_selected(airline):
    if airline == '':
        return [], True, [], True

    # retrieve the airline_id for the selected airline
    selected_airline_as_list = airlines_df.query(f'Name=="{airline}"')['Airline_id'].tolist()
    airline_id = selected_airline_as_list[0]

    # get all routes for the selected airline
    airline_routes_df = routes_df.copy()
    airline_routes_df = airline_routes_df.query(f'Airline_id=={airline_id}')



    # get city name for start and destination airports
    start_airport_ids = airline_routes_df['Source_airport_id'].to_list()
    start_city_df = airport_df[airport_df['Airport_id'].isin(start_airport_ids)]



    # populate source and destination city list for the dropdown controls
    destination_airport_ids = list(airline_routes_df['Destination_airport_id'])
    destination_city_df = airport_df[airport_df['Airport_id'].isin(destination_airport_ids)]

    start_city_options = [{'label': col, 'value': col} for col in start_city_df['City']]
    start_city_options = sorted(start_city_options, key=itemgetter('value'))
    destination_city_options = [{'label': col, 'value': col} for col in destination_city_df[
        'City']]
    destination_city_options = sorted(destination_city_options, key=itemgetter('value'))

    return start_city_options, False, destination_city_options, False


# start or destination city selected, populate start or destination airport
#
@app.callback([Output('start-city-airport', 'options'),
               Output('start-city-airport', 'disabled'),
               Output('destination-city-airport', 'options'),
               Output('destination-city-airport', 'disabled')],
              [Input('airline', 'value'),
               Input('start-city', 'value'),
               Input('destination-city', 'value')])
def populate_airport_controls_after_city_selected(airline, start_city, destination_city):
    if start_city == '':
        start_city_airport_options = []
        start_city_airport_disable = True
    else:
        # retrieve the airline_id for a given airline name
        ctl_routes_df = routes_df.copy()
        selected_airline_as_list = airlines_df.query(f'Name=="{airline}"')['Airline_id'].tolist()
        airline_id = selected_airline_as_list[0]

        # get all routes for the selected airline
        #ctl_routes_df = ctl_routes_df.query(f'Airline_id=="{airline_id}"')
        ctl_routes_df = ctl_routes_df.query(f'Airline_id=={airline_id}')
        # get source airport
        source_airport_ids = ctl_routes_df['Source_airport_id'].to_list()
        ctl_src_airport_df = airport_df[airport_df['Airport_id'].isin(source_airport_ids)]
        ctl_src_airport_df = ctl_src_airport_df.query(f'City=="{start_city}"')
        start_city_airport_options = [{'label': col, 'value': col} for col in
                                      ctl_src_airport_df['Name']]
        start_city_airport_options.sort()
        start_city_airport_disable = False

    if destination_city == '':
        destination_city_airport_options = []
        destination_city_airport_disable = True
    else:
        # retrieve the airline_id for a given airline name
        ctl_routes_df = routes_df.copy()
        selected_airline_as_list = airlines_df.query(f'Name=="{airline}"')['Airline_id'].tolist()
        airline_id = selected_airline_as_list[0]

        # get all routes for the selected airline
        #ctl_routes_df = ctl_routes_df.query(f'Airline_id=="{airline_id}"')
        ctl_routes_df = ctl_routes_df.query(f'Airline_id=={airline_id}')

        # get destination airport
        destination_airport_ids = ctl_routes_df['Destination_airport_id'].to_list()
        ctl_dest_airport_df = airport_df[airport_df['Airport_id'].isin(destination_airport_ids)]
        ctl_dest_airport_df = ctl_dest_airport_df.query(f'City=="{destination_city}"')
        destination_city_airport_options = [{'label': col, 'value': col} for col in
                                            ctl_dest_airport_df['Name']]
        destination_city_airport_options.sort()
        destination_city_airport_disable = False

    return start_city_airport_options, start_city_airport_disable, \
           destination_city_airport_options, destination_city_airport_disable


@app.callback(Output('map', 'figure'),
              [Input('start-city', 'value'),
               Input('destination-city', 'value'),
               Input('start-city-airport', 'value'),
               Input('destination-city-airport', 'value')],
              [State('map', 'relayoutData')])
def make_map(start_city, destination_city,start_city_airport,destination_city_airport, map_layout):
    traces = []
    for name, df in airport_df.groupby('City'):
        trace = dict(
            type='scattermapbox',
            lon=df['Longitude'],
            lat=df['Latitude'],
            text=df['City'],
            showlegend=False,
            marker=dict(
                size=10 if name in [start_city, destination_city] else 5,
                opacity=0.95 if name in [start_city, destination_city] else 0.65,
                symbol='circle',
                color='red' if name in [start_city, destination_city] else 'blue',
            ),
            visible=True
        )
        traces.append(trace)


    # relayoutData is None by default, and {'autosize': True} without relayout action
    if map_layout is not None:
        if 'mapbox.center' in map_layout.keys():
            lon = float(map_layout['mapbox.center']['lon'])
            lat = float(map_layout['mapbox.center']['lat'])
            zoom = float(map_layout['mapbox.zoom'])
            layout['mapbox']['center']['lon'] = lon
            layout['mapbox']['center']['lat'] = lat
            layout['mapbox']['zoom'] = zoom


    if start_city_airport != '' and destination_city_airport != '':
        start_ariport = airport_df.query(f'Name=="{start_city_airport}"')
        des_ariport = airport_df.query(f'Name=="{destination_city_airport}"')
        lon1 = start_ariport.Longitude.astype('float').to_list()[0]
        lat1 = start_ariport.Latitude.astype('float').to_list()[0]
        lon2 = des_ariport.Longitude.astype('float').to_list()[0]
        lat2 = des_ariport.Latitude.astype('float').to_list()[0]
        lat_list = [lat1,lat2]
        lon_list = [lon1,lon2]
        fig = go.Figure(go.Scattermapbox(
            mode="markers+text+lines",
            lat=lat_list,
            lon=lon_list,
            marker={'size': 10}))
        for name, df in airport_df.groupby('City'):
            trace = dict(
                type='scattermapbox',
                lon=df['Longitude'],
                lat=df['Latitude'],
                text=df['City'],
                showlegend=False,
                marker=dict(
                    size=10 if name in [start_city, destination_city] else 5,
                    opacity=0.95 if name in [start_city, destination_city] else 0.65,
                    symbol='circle',
                    color='red' if name in [start_city, destination_city] else 'blue',
                ),
                visible=True
            )
            fig.add_trace(trace)

        fig.update_layout(
            margin={'l': 5, 't': 5, 'b': 5, 'r': 5},
            mapbox={
                'accesstoken': mapbox_access_token,
                'style': "open-street-map",
                'center': {'lon': -98.5795, 'lat': 39.8283},
                'zoom': 3},
            showlegend=False)
        return fig
    figure = dict(data=traces, layout=layout)
    return figure


@app.callback(Output('display-selected-values', 'children'),
              [Input('start-city-airport', 'value'),
               Input('destination-city-airport', 'value')])
def find_shortest_route(start_city_airport, destination_city_airport):
    distance = 0
    if start_city_airport != '' and destination_city_airport !='':
        start_ariport = airport_df.query(f'Name=="{start_city_airport}"')
        des_ariport = airport_df.query(f'Name=="{destination_city_airport}"')
        lon1 = start_ariport.Longitude.astype('float').to_list()[0]
        lat1 = start_ariport.Latitude.astype('float').to_list()[0]
        lon2 = des_ariport.Longitude.astype('float').to_list()[0]
        lat2 = des_ariport.Latitude.astype('float').to_list()[0]
        distance = round(helper.compute_distance_in_kilometers(lon1, lat1, lon2, lat2))

        return u'The shortest airline route from {} to {} is {} KM.'.format(start_city_airport, destination_city_airport, distance)


@app.callback(Output('destination-city-info', 'children'),
               Input('destination-city', 'value'))

#search for descriptions of corresponding destination cities
def destination_city_description(destination_city):
    if destination_city == 'New York City':
        return f'Welcome to {destination_city}. New York City (NYC), often simply called New York, is the most populous city in the United States. Located at the southern tip of the State of New York, the city is the center of the New York metropolitan area, the largest metropolitan area in the world by urban landmass.'
    elif destination_city == "Los Angeles":
        return f'Welcome to {destination_city}. Los Angeles is the largest city in California. With an estimated population of nearly four million people, it is the second most populous city in the United States (after New York City) and the third most populous city in North America (after Mexico City and New York City). Los Angeles is known for its Mediterranean climate, ethnic diversity, Hollywood entertainment industry, and its sprawling metropolis.'
    elif destination_city == "Chicago":
        return f"Welcome to {destination_city}. Chicago is the most populous city in the U.S. state of Illinois, and the third most populous city in the United States. Chicago is an international hub for finance, culture, commerce, industry, education, technology, telecommunications, and transportation. It is the site of the creation of the first standardized futures contracts, issued by the Chicago Board of Trade, which today is part of the largest and most diverse derivatives market in the world, generating 20% of all volume in commodities and financial futures alone."
    elif destination_city == "Dallas":
        return f"Welcome to {destination_city}. Dallas is a city in the U.S. state of Texas and the largest city in and seat of Dallas County. Located in North Texas, the city of Dallas is the main core of the largest metropolitan area in the Southern United States and the largest inland metropolitan area in the U.S. that lacks any navigable link to the sea."
    elif destination_city == "Houston":
        return f"Welcome to {destination_city}. Houston is the most populous city in the U.S. state of Texas, fourth-most populous city in the United States, most populous city in the Southern United States, as well as the sixth-most populous in North America, with an estimated 2019 population of 2,320,268."
    elif destination_city == "Washington":
        return f"Welcome to {destination_city}. Washington, D.C. is the capital city of the United States.It is located on the Potomac River bordering Maryland and Virginia, with Congress holding its first session there in 1800. The city was named for George Washington, the first president of the United States and a Founding Father, and the federal district is named after Columbia, a female personification of the nation. As the seat of the U.S. federal government and several international organizations, the city is an important world political capital."
    elif destination_city == "Miami":
        return f"Welcome to {destination_city}. Miami is a coastal metropolis located in southeastern Florida in the United States. Miami is a major center and leader in finance, commerce, culture, arts, and international trade."
    elif destination_city == "Philadelphia":
        return f"Welcome to {destination_city}. Philadelphia, colloquially Philly, is a city in the state of Pennsylvania in the United States. It is the sixth-most populous city in the United States and the most populous city in the state of Pennsylvania. It is also the second-most populous city in the Northeastern United States, behind New York City."
    elif destination_city == "Atlanta":
        return f"Welcome to {destination_city}. Atlanta is the capital and most populous city of the U.S. state of Georgia. The city serves as the cultural and economic center of the Atlanta metropolitan area, home to more than 6 million people and the ninth-largest metropolitan area in the nation."
    elif destination_city == "Phoenix":
        return f"Welcome to {destination_city}. Phoenix is the capital and most populous city in Arizona, with 1,680,992 people (as of 2019). It is also the fifth-most populous city in the United States, the largest state capital by population,and the only state capital with a population of more than one million residents."
    elif destination_city == "Boston":
        return f"Welcome to {destination_city}. Boston is one of the oldest municipalities in the United States, founded on the Shawmut Peninsula in 1630 by Puritan settlers from the English town of the same name. Upon American independence from Great Britain, the city continued to be an important port and manufacturing hub as well as a center for education and culture. Today, Boston is a thriving center of scientific research. The Boston area's many colleges and universities make it a world leader in higher education."
    elif destination_city == "San Francisco":
        return f"Welcome to {destination_city}. San Francisco is a cultural, commercial, and financial center in Northern California. A popular tourist destination, San Francisco is known for its cool summers, fog, steep rolling hills, eclectic mix of architecture, and landmarks, including the Golden Gate Bridge, cable cars, the former Alcatraz Federal Penitentiary, Fisherman's Wharf, and its Chinatown district."
    elif destination_city == "Detroit":
        return f"Welcome to {destination_city}. Detroit's diverse culture has had both local and international influence, particularly in music, with the city giving rise to the genres of Motown and techno, and playing an important role in the development of jazz, hip-hop, rock, and punk music."
    elif destination_city == "Seattle":
        return f"Welcome to {destination_city}. Seattle is a seaport city on the West Coast of the United States. The Seattle area developed into a technology center from the 1980s onwards with companies like Microsoft becoming established in the region; Microsoft founder Bill Gates is a Seattleite by birth."
    elif destination_city == "Minneapolis":
        return f"Welcome to {destination_city}. Minneapolis is the most populous city in the US state of Minnesota and the seat of Hennepin County. With an estimated population of 429,606 as of 2019, it is the 46th most populous city in the US."
    elif destination_city == "San Diego":
        return f"Welcome to {destination_city}. San Diego is a city in the U.S. state of California on the coast of the Pacific Ocean and immediately adjacent to the United States–Mexico border. The city is known for its mild year-round climate, natural deep-water harbor, extensive beaches and parks, long association with the United States Navy and Marine Corps, and recent emergence as a healthcare and biotechnology development center."
    elif destination_city == "Tampa":
        return f"Welcome to {destination_city}. Tampa is a major city that serves as the county seat of Hillsborough County, Florida, United States. It is on the west coast of Florida on Tampa Bay, near the Gulf of Mexico. Tampa is the largest city in the Tampa Bay area."
    elif destination_city == "Denver":
        return f"Welcome to {destination_city}. Denver is the capital and most populous city of the U.S. State of Colorado. Denver is located in the South Platte River Valley on the western edge of the High Plains just east of the Front Range of the Rocky Mountains."
    elif destination_city == "St. Louis":
        return f"Welcome to {destination_city}. St. Louis is the second-largest city in Missouri, United States. It sits near the confluence of the Mississippi and the Missouri Rivers, on the western bank of the latter."
    elif destination_city == "Baltimore":
        return f"Welcome to {destination_city}. Baltimore is the largest independent city in the country and was designated as such by the Constitution of Maryland in 1851. With hundreds of identified districts, Baltimore has been dubbed a 'city of neighborhoods'. Baltimore has more public statues and monuments per capita than any other city in the country."
    elif destination_city == "Charlotte":
        return f"Welcome to {destination_city}. Charlotte is the most populous city in the U.S. state of North Carolina. The city is the cultural, economic, and transportation center of the Charlotte metropolitan area, whose population ranks 22nd in the U.S., and had a population of 2,569,213, in 2018."
    elif destination_city == "Orlando":
        return f"Welcome to {destination_city}. Orlando is one of the most-visited cities in the world primarily driven by tourism, major events, and convention traffic; in 2018, the city drew more than 75 million visitors."
    elif destination_city == "San Antonio":
        return f"Welcome to {destination_city}. San Antonio is the seventh-most populous city in the United States, and the second-most populous city in both Texas and the Southern United States, with 1,547,253 residents in 2019."
    elif destination_city == "Portland":
        return f"Welcome to {destination_city}. Portland is the largest and most populous city in the U.S. state of Oregon and the seat of Multnomah County. It is a major port in the Willamette Valley region of the Pacific Northwest, at the confluence of the Willamette and Columbia rivers in Northwestern Oregon."


if __name__ == '__main__':
    app.run_server()
